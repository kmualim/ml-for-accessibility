#!/env/bin/bash

for f in stair*
do 
    name=`basename $f`
    echo "processing file: $name"
    cat $f| awk '{print $NF}' >> elevator_down_labels_$name.csv
    awk '{print $2}' $f >> elevator_time_$name.csv
    awk '{print $3}' $f >> elevator_x_$name.csv
    awk '{print $4}' $f >> elevator_y_$name.csv
    awk '{print $5}' $f >> elevator_z_$name.csv
done
